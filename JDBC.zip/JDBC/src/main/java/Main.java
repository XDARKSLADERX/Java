import java.util.Scanner;
import java.util.List;
import model.Usuario;
import repository.UsuarioRepository;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        UsuarioRepository usuarioRepository = new UsuarioRepository();

        while (true) {
            System.out.println("1. Agregar usuario");
            System.out.println("2. Ver todos los usuarios");
            System.out.println("3. Buscar por nombre");
            System.out.println("4. Buscar por nombre");
            System.out.println("5. Cambiar usuario");
            System.out.println("6. Borrar usuario");
            System.out.println("7. Salir");
            System.out.print("Elige una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            if (opcion == 1) {
                System.out.print("Nombre: ");
                String nombre = scanner.nextLine();
                System.out.print("Edad: ");
                Long edad = scanner.nextLong();
                scanner.nextLine();

                Usuario usuario = new Usuario(nombre, edad);
                usuarioRepository.insertarUsuario(usuario);
                System.out.println("Usuario agregado!");
            } else if (opcion == 2) {
                System.out.println("Lista de usuarios:");
                List<Usuario> usuarios = usuarioRepository.listarUsuarios();
                for (Usuario u : usuarios) {
                    System.out.println("Id: " + u.getId() + " Nombre: " + u.getNombre() + " Edad: " + u.getEdad());
                }
            } else if (opcion == 3) {
                System.out.print("Nombre a buscar: ");
                String nombre = scanner.nextLine();
                List<Usuario> usuarios = usuarioRepository.filtrarUsuariosPorNombre(nombre);
                System.out.println("Usuarios encontrados:");
                for (Usuario u : usuarios) {
                    System.out.println("Id: " + u.getId() + " Nombre: " + u.getNombre() + " Edad: " + u.getEdad());
                }
            } else if (opcion == 4) {
                System.out.print("Edad a buscar: ");
                String nombre = scanner.nextLine();
                scanner.nextLine();
                List<Usuario> usuarios = usuarioRepository.filtrarUsuariosPorNombre(nombre);
                System.out.println("Usuarios encontrados:");
                for (Usuario u : usuarios) {
                    System.out.println("Id: " + u.getId() + " Nombre: " + u.getNombre() + " Edad: " + u.getEdad());
                }
            } else if (opcion == 5) {
                System.out.print("Id del usuario a cambiar: ");
                Long id = scanner.nextLong();
                scanner.nextLine();
                System.out.print("Nuevo nombre: ");
                String nombre = scanner.nextLine();
                System.out.print("Nueva edad: ");
                Long edad = scanner.nextLong();
                scanner.nextLine();

                Usuario usuario = new Usuario(id, nombre, edad);
                usuarioRepository.actualizarUsuario(usuario);
                System.out.println("Usuario cambiado!");
            } else if (opcion == 6) {
                System.out.print("Id del usuario a borrar: ");
                Long id = scanner.nextLong();
                scanner.nextLine();
                usuarioRepository.eliminarUsuario(id);
                System.out.println("Usuario borrado!");
            } else if (opcion == 7) {
                System.out.println("Adiós!");
                break;
            } else {
                System.out.println("Hazlo del 1 al 7 >:(.");
            }
        }

        scanner.close();
    }
}